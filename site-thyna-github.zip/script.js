const startDate = new Date("2026-08-29T00:00:00-03:00");

function calendarDiff(start,end){
  let cursor=new Date(start),months=0;
  while(true){let next=new Date(cursor);next.setMonth(next.getMonth()+1);if(next<=end){cursor=next;months++;}else break;}
  const s=Math.max(0,Math.floor((end-cursor)/1000));
  return {months,days:Math.floor(s/86400),hours:Math.floor((s%86400)/3600),minutes:Math.floor((s%3600)/60),seconds:s%60};
}
function updateTimer(){
  const d=calendarDiff(startDate,new Date());
  months.textContent=d.months;days.textContent=d.days;
  hours.textContent=String(d.hours).padStart(2,"0");
  minutes.textContent=String(d.minutes).padStart(2,"0");
  seconds.textContent=String(d.seconds).padStart(2,"0");
}
updateTimer();setInterval(updateTimer,1000);

document.querySelectorAll("[data-scroll]").forEach(b=>b.onclick=()=>document.querySelector(b.dataset.scroll)?.scrollIntoView({behavior:"smooth"}));

const music=document.getElementById("music"),musicToggle=document.getElementById("musicToggle");
musicToggle.onclick=async()=>{if(music.paused){try{await music.play();musicToggle.textContent="Ⅱ"}catch{alert("Adicione sua música em assets/music/musica.mp3 para usar o player.")}}else{music.pause();musicToggle.textContent="♫"}};

const modal=document.getElementById("modal");
document.getElementById("surpriseBtn").onclick=()=>{modal.classList.add("show");modal.setAttribute("aria-hidden","false")};
function closeModal(){modal.classList.remove("show");modal.setAttribute("aria-hidden","true")}
document.getElementById("closeModal").onclick=closeModal;
document.getElementById("modalFinal").onclick=()=>{closeModal();document.getElementById("final").scrollIntoView({behavior:"smooth"})};
modal.onclick=e=>{if(e.target===modal)closeModal()};

const observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting)e.target.classList.add("visible")}),{threshold:.12});
document.querySelectorAll(".reveal").forEach(e=>observer.observe(e));

for(let i=0;i<45;i++){const s=document.createElement("i");s.className="star";s.style.left=Math.random()*100+"%";s.style.top=Math.random()*100+"%";s.style.animationDelay=Math.random()*4+"s";document.getElementById("stars").appendChild(s)}
