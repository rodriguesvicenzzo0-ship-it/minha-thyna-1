# Para minha Thyna ♡

Site romântico em tema roxo, pronto para GitHub Pages.

## Publicar
1. Extraia o ZIP.
2. Coloque uma música que você tenha direito de usar em `assets/music/musica.mp3`.
3. Suba os arquivos para um repositório do GitHub.
4. Em Settings → Pages, selecione a branch `main` e a pasta `/ (root)`.

## Contador
Começa em 29/08/2026 às 00:00 (horário de Brasília). Para mudar o horário, edite `startDate` em `script.js`.

As duas fotos enviadas foram incluídas em `assets/images/`.
